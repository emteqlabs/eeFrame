//
//  eeFrame.h
//  eeFrame
//
//  Created by Andy Cleal on 10/02/2023.
//

#import <Foundation/Foundation.h>

//! Project version number for eeFrame.
FOUNDATION_EXPORT double eeFrameVersionNumber;

//! Project version string for eeFrame.
FOUNDATION_EXPORT const unsigned char eeFrameVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <eeFrame/PublicHeader.h>

#import "expEng.h"

