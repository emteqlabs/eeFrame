//
//  expEng.h
//  eeFrame
//
//  Created by Andy Cleal on 10/02/2023.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface expEng : NSObject

- (void)userSet:(NSString*)sLearntSet;
- (NSString*)userGet;
//- (void)dataNewFrame:(float[])fVals;
- (NSString*)dataStartSaving;
- (void)dataStopSaving;
- (bool)dataIsSaving;

@end

NS_ASSUME_NONNULL_END
